﻿using System;

public class Calculator
{
    public int Add(int a, int b)
    {
        return a + b;
    }
    public double Add(double a, double b)
    {
        return a + b;
    }
    public int Add(int[] numbers)
    {
        int sum = 0;
        foreach (var number in numbers)
        {
            sum += number;
        }
        return sum;
    }

    public double Add(double[] numbers)
    {
        double sum = 0.0;
        foreach (var number in numbers)
        {
            sum += number;
        }
        return sum;
    }
}

class Program
{
    static void Main(string[] args)
    {
        Calculator calc = new Calculator();

        Console.WriteLine("Сумма двух целых чисел: " + calc.Add(5, 10));
        Console.WriteLine("Сумма двух дробных чисел: " + calc.Add(5.5, 10.2));
        Console.WriteLine("Сумма массива целых чисел: " + calc.Add(new int[] { 1, 2, 3, 4 }));
        Console.WriteLine("Сумма массива дробных чисел: " + calc.Add(new double[] { 1.1, 2.2, 3.3 }));
    }
}