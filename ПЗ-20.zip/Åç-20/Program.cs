﻿using System;
public class SumWithoutLoop
{
    public static int Sum(int num)
    {
        if (num == 0)
        {
            return 0;
        }
        else
        {
            return num + Sum(int.Parse(Console.ReadLine()));
        }
    }

    public static void Main(string[] args)
    {
        Console.WriteLine("Введите последовательность чисел, завершающуюся 0:");
        int sum = Sum(int.Parse(Console.ReadLine()));
        Console.WriteLine($"\b\b= {sum}");
    }
}